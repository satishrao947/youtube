body{
	padding: 25px;
}
.title {
	color: #5C6AC4;
}